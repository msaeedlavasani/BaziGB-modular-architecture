(()=>{var e={};e.id=340,e.ids=[340],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},40760:(e,r,t)=>{"use strict";t.r(r),t.d(r,{GlobalError:()=>n.a,__next_app__:()=>p,originalPathname:()=>u,pages:()=>c,routeModule:()=>m,tree:()=>d}),t(7014),t(34407),t(87824);var a=t(93282),i=t(5736),o=t(93906),n=t.n(o),s=t(36880),l={};for(let e in s)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>s[e]);t.d(r,l);let d=["",{children:["tournaments",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,7014)),"/Users/msl/Documents/GitHub/BaziGB-modular-architecture/apps/web/src/app/tournaments/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(t.bind(t,34407)),"/Users/msl/Documents/GitHub/BaziGB-modular-architecture/apps/web/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,87824,23)),"next/dist/client/components/not-found-error"]}],c=["/Users/msl/Documents/GitHub/BaziGB-modular-architecture/apps/web/src/app/tournaments/page.tsx"],u="/tournaments/page",p={require:t,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:i.x.APP_PAGE,page:"/tournaments/page",pathname:"/tournaments",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},97572:(e,r,t)=>{Promise.resolve().then(t.bind(t,48288))},48288:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>el});var a=t(73227),i=t(23677),o=t(20649),n=t(76753),s=t(36414),l=t(69650),d=t(65168),c=t(14906),u=t(51732),p=t(67997),m=t(23988),h=t(32090),b=t(70662),x=t(48612),g=t(27610),f=t(12131),y=t(40224),v=t(91126),Z=t(97785),j=t(98964),k=t(68826),C=t(65078),w=t(54284),P=t(25349),S=t(30096),q=t(82832),$=t(17409);function F(e){return(0,$.ZP)("MuiLinearProgress",e)}(0,q.Z)("MuiLinearProgress",["root","colorPrimary","colorSecondary","determinate","indeterminate","buffer","query","dashed","dashedColorPrimary","dashedColorSecondary","bar","barColorPrimary","barColorSecondary","bar1Indeterminate","bar1Determinate","bar1Buffer","bar2Indeterminate","bar2Buffer"]);let M=["className","color","value","valueBuffer","variant"],R=e=>e,z,B,W,I,_,A,L=(0,j.F4)(z||(z=R`
  0% {
    left: -35%;
    right: 100%;
  }

  60% {
    left: 100%;
    right: -90%;
  }

  100% {
    left: 100%;
    right: -90%;
  }
`)),G=(0,j.F4)(B||(B=R`
  0% {
    left: -200%;
    right: 100%;
  }

  60% {
    left: 107%;
    right: -8%;
  }

  100% {
    left: 107%;
    right: -8%;
  }
`)),N=(0,j.F4)(W||(W=R`
  0% {
    opacity: 1;
    background-position: 0 -23px;
  }

  60% {
    opacity: 0;
    background-position: 0 -23px;
  }

  100% {
    opacity: 1;
    background-position: -200px -23px;
  }
`)),D=e=>{let{classes:r,variant:t,color:a}=e,i={root:["root",`color${(0,w.Z)(a)}`,t],dashed:["dashed",`dashedColor${(0,w.Z)(a)}`],bar1:["bar",`barColor${(0,w.Z)(a)}`,("indeterminate"===t||"query"===t)&&"bar1Indeterminate","determinate"===t&&"bar1Determinate","buffer"===t&&"bar1Buffer"],bar2:["bar","buffer"!==t&&`barColor${(0,w.Z)(a)}`,"buffer"===t&&`color${(0,w.Z)(a)}`,("indeterminate"===t||"query"===t)&&"bar2Indeterminate","buffer"===t&&"bar2Buffer"]};return(0,Z.Z)(i,F,r)},T=(e,r)=>"inherit"===r?"currentColor":e.vars?e.vars.palette.LinearProgress[`${r}Bg`]:"light"===e.palette.mode?(0,k.$n)(e.palette[r].main,.62):(0,k._j)(e.palette[r].main,.5),H=(0,P.ZP)("span",{name:"MuiLinearProgress",slot:"Root",overridesResolver:(e,r)=>{let{ownerState:t}=e;return[r.root,r[`color${(0,w.Z)(t.color)}`],r[t.variant]]}})(({ownerState:e,theme:r})=>(0,y.Z)({position:"relative",overflow:"hidden",display:"block",height:4,zIndex:0,"@media print":{colorAdjust:"exact"},backgroundColor:T(r,e.color)},"inherit"===e.color&&"buffer"!==e.variant&&{backgroundColor:"none","&::before":{content:'""',position:"absolute",left:0,top:0,right:0,bottom:0,backgroundColor:"currentColor",opacity:.3}},"buffer"===e.variant&&{backgroundColor:"transparent"},"query"===e.variant&&{transform:"rotate(180deg)"})),J=(0,P.ZP)("span",{name:"MuiLinearProgress",slot:"Dashed",overridesResolver:(e,r)=>{let{ownerState:t}=e;return[r.dashed,r[`dashedColor${(0,w.Z)(t.color)}`]]}})(({ownerState:e,theme:r})=>{let t=T(r,e.color);return(0,y.Z)({position:"absolute",marginTop:0,height:"100%",width:"100%"},"inherit"===e.color&&{opacity:.3},{backgroundImage:`radial-gradient(${t} 0%, ${t} 16%, transparent 42%)`,backgroundSize:"10px 10px",backgroundPosition:"0 -23px"})},(0,j.iv)(I||(I=R`
    animation: ${0} 3s infinite linear;
  `),N)),O=(0,P.ZP)("span",{name:"MuiLinearProgress",slot:"Bar1",overridesResolver:(e,r)=>{let{ownerState:t}=e;return[r.bar,r[`barColor${(0,w.Z)(t.color)}`],("indeterminate"===t.variant||"query"===t.variant)&&r.bar1Indeterminate,"determinate"===t.variant&&r.bar1Determinate,"buffer"===t.variant&&r.bar1Buffer]}})(({ownerState:e,theme:r})=>(0,y.Z)({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left",backgroundColor:"inherit"===e.color?"currentColor":(r.vars||r).palette[e.color].main},"determinate"===e.variant&&{transition:"transform .4s linear"},"buffer"===e.variant&&{zIndex:1,transition:"transform .4s linear"}),({ownerState:e})=>("indeterminate"===e.variant||"query"===e.variant)&&(0,j.iv)(_||(_=R`
      width: auto;
      animation: ${0} 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite;
    `),L)),X=(0,P.ZP)("span",{name:"MuiLinearProgress",slot:"Bar2",overridesResolver:(e,r)=>{let{ownerState:t}=e;return[r.bar,r[`barColor${(0,w.Z)(t.color)}`],("indeterminate"===t.variant||"query"===t.variant)&&r.bar2Indeterminate,"buffer"===t.variant&&r.bar2Buffer]}})(({ownerState:e,theme:r})=>(0,y.Z)({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left"},"buffer"!==e.variant&&{backgroundColor:"inherit"===e.color?"currentColor":(r.vars||r).palette[e.color].main},"inherit"===e.color&&{opacity:.3},"buffer"===e.variant&&{backgroundColor:T(r,e.color),transition:"transform .4s linear"}),({ownerState:e})=>("indeterminate"===e.variant||"query"===e.variant)&&(0,j.iv)(A||(A=R`
      width: auto;
      animation: ${0} 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) 1.15s infinite;
    `),G)),U=i.forwardRef(function(e,r){let t=(0,S.i)({props:e,name:"MuiLinearProgress"}),{className:i,color:o="primary",value:n,valueBuffer:s,variant:l="indeterminate"}=t,d=(0,f.Z)(t,M),c=(0,y.Z)({},t,{color:o,variant:l}),u=D(c),p=(0,C.V)(),m={},h={bar1:{},bar2:{}};if(("determinate"===l||"buffer"===l)&&void 0!==n){m["aria-valuenow"]=Math.round(n),m["aria-valuemin"]=0,m["aria-valuemax"]=100;let e=n-100;p&&(e=-e),h.bar1.transform=`translateX(${e}%)`}if("buffer"===l&&void 0!==s){let e=(s||0)-100;p&&(e=-e),h.bar2.transform=`translateX(${e}%)`}return(0,a.jsxs)(H,(0,y.Z)({className:(0,v.Z)(u.root,i),ownerState:c,role:"progressbar"},m,{ref:r},d,{children:["buffer"===l?(0,a.jsx)(J,{className:u.dashed,ownerState:c}):null,(0,a.jsx)(O,{className:u.bar1,ownerState:c,style:h.bar1}),"determinate"===l?null:(0,a.jsx)(X,{className:u.bar2,ownerState:c,style:h.bar2})]}))});var E=t(79995),V=t(15135),K=t(68833),Q=t(42073),Y=t(17938),ee=t(18417),er=t(99615),et=t(40997),ea=t(75142),ei=t(53987);let eo={registration:{color:"success",label:"Registration Open"},in_progress:{color:"warning",label:"In Progress"},completed:{color:"default",label:"Completed"}};function en({game:e,size:r=20}){return"chess"===e?a.jsx(n.Z,{component:"span",sx:{fontSize:1.2*r,lineHeight:1,userSelect:"none"},"aria-hidden":!0,children:"♞"}):a.jsx(n.Z,{component:"svg",viewBox:"0 0 24 24",sx:{width:r,height:r,fill:"none",stroke:"currentColor",strokeWidth:2.2,strokeLinecap:"round"},"aria-hidden":!0,children:a.jsx("path",{d:"M3 8h18M3 16h18M8 3v18M16 3v18"})})}let es=[{key:"all",label:"All"},{key:"registration",label:"Open"},{key:"in_progress",label:"In Progress"},{key:"completed",label:"Completed"}];function el(){let{user:e}=(0,ea.a)(),r=(0,s.Z)(),[t,f]=(0,i.useState)([]),[y,v]=(0,i.useState)(!0),[Z,j]=(0,i.useState)(null),[k,C]=(0,i.useState)("all"),[w,P]=(0,i.useState)({}),[S,q]=(0,i.useState)(null),$=(0,i.useCallback)(async()=>{v(!0),j(null);try{let e=await (0,ei.BR)();f(e)}catch(e){j(e?.message||"Could not load tournaments.")}finally{v(!1)}},[]),F=(0,i.useMemo)(()=>"all"===k?t:t.filter(e=>e.status===k),[t,k]),M=async r=>{if(!("registration"!==r.status||w[r.id]?.joined)&&e){q(r.id);try{let t=await (0,ei.UI)(r.id,e.id);P(e=>({...e,[r.id]:t})),t.joined&&f(e=>e.map(e=>e.id===r.id?{...e,playersJoined:Math.min(e.maxPlayers,e.playersJoined+1)}:e))}catch(e){j(e?.message||"Could not join the tournament.")}finally{q(null)}}},R=t.filter(e=>"registration"===e.status).length;return a.jsx(n.Z,{sx:{flex:1,bgcolor:"background.default"},children:(0,a.jsxs)(l.Z,{maxWidth:"md",sx:{py:6},children:[(0,a.jsxs)(n.Z,{sx:{display:"flex",flexWrap:"wrap",alignItems:"flex-end",justifyContent:"space-between",gap:2,mb:4},children:[(0,a.jsxs)(n.Z,{children:[(0,a.jsxs)(d.Z,{variant:"h4",component:"h1",sx:{fontWeight:800,display:"flex",alignItems:"center",gap:1.5},children:[a.jsx(E.Z,{size:32,style:{color:r.palette.primary.light}}),"Tournaments"]}),a.jsx(d.Z,{variant:"body2",color:"text.secondary",sx:{mt:.5},children:R>0?`${R} tournament${1===R?"":"s"} open for registration right now.`:"Pick a tournament and claim your spot."})]}),a.jsx(c.Z,{variant:"outlined",onClick:()=>void $(),disabled:y,startIcon:a.jsx(V.Z,{size:16,className:y?"animate-spin":""}),sx:{borderColor:"divider",color:"text.secondary","&:hover":{borderColor:"text.primary",color:"text.primary",bgcolor:(0,u.Fq)(r.palette.text.primary,.05)}},children:"Refresh"})]}),a.jsx(p.Z,{direction:"row",spacing:1,useFlexGap:!0,sx:{mb:4,flexWrap:"wrap"},children:es.map(e=>a.jsx(c.Z,{size:"small",variant:k===e.key?"contained":"outlined",onClick:()=>C(e.key),sx:{borderRadius:2,px:2,fontWeight:700,...k===e.key?{bgcolor:(0,u.Fq)(r.palette.primary.main,.2),color:"primary.light",border:"1px solid",borderColor:(0,u.Fq)(r.palette.primary.main,.4),"&:hover":{bgcolor:(0,u.Fq)(r.palette.primary.main,.3)}}:{color:"text.secondary",borderColor:"divider","&:hover":{borderColor:"text.disabled",color:"text.primary"}}},children:e.label},e.key))}),Z&&a.jsx(m.Z,{severity:"error",variant:"outlined",sx:{mb:4,borderRadius:2},children:Z}),a.jsx(n.Z,{component:"section",children:y?a.jsx(h.ZP,{container:!0,spacing:2,children:Array.from({length:4}).map((e,t)=>a.jsx(h.ZP,{xs:12,sm:6,children:a.jsx(b.Z,{variant:"rectangular",height:224,sx:{borderRadius:4,bgcolor:(0,u.Fq)(r.palette.background.paper,.6)}})},t))}):0===F.length?(0,a.jsxs)(x.Z,{variant:"outlined",sx:{p:8,textAlign:"center",borderRadius:4,borderStyle:"dashed",bgcolor:"transparent"},children:[a.jsx(K.Z,{size:40,style:{color:r.palette.text.disabled,margin:"0 auto"}}),a.jsx(d.Z,{sx:{mt:2,fontWeight:600,color:"text.secondary"},children:"No tournaments here"}),a.jsx(d.Z,{variant:"body2",color:"text.disabled",sx:{mt:.5},children:"Check back soon — new tournaments are added regularly."})]}):a.jsx(h.ZP,{container:!0,spacing:2.5,children:F.map(t=>{let i=eo[t.status],s=!!w[t.id]?.joined,l=w[t.id],m=t.playersJoined>=t.maxPlayers,b=Math.min(100,t.playersJoined/t.maxPlayers*100);return a.jsx(h.ZP,{xs:12,sm:6,children:(0,a.jsxs)(x.Z,{elevation:0,sx:{p:3,height:"100%",display:"flex",flexDirection:"column",borderRadius:4,border:"1px solid",borderColor:"divider",bgcolor:(0,u.Fq)(r.palette.background.paper,.6),transition:"all 0.2s","&:hover":{borderColor:(0,u.Fq)(r.palette.primary.main,.4),boxShadow:`0 8px 30px ${(0,u.Fq)(r.palette.common.black,.3)}`}},children:[(0,a.jsxs)(n.Z,{sx:{display:"flex",justifyContent:"space-between",alignItems:"flex-start",mb:2},children:[a.jsx(n.Z,{sx:{width:44,height:44,borderRadius:2.5,border:"1px solid",borderColor:(0,u.Fq)(r.palette.primary.main,.3),bgcolor:(0,u.Fq)(r.palette.primary.main,.1),display:"flex",alignItems:"center",justifyContent:"center",color:"primary.light"},children:a.jsx(en,{game:t.gameType,size:"chess"===t.gameType?28:24})}),a.jsx(g.Z,{label:i.label,size:"small",color:i.color,variant:"outlined",icon:a.jsx(n.Z,{sx:{width:6,height:6,borderRadius:"50%",bgcolor:"currentColor",ml:1}}),sx:{height:24,fontWeight:700,fontSize:"11px",textTransform:"uppercase",letterSpacing:"0.025em","& .MuiChip-icon":{ml:.5,mr:0}}})]}),a.jsx(d.Z,{variant:"h6",sx:{fontWeight:800,lineHeight:1.2,mb:1},children:t.name}),a.jsx(d.Z,{variant:"body2",color:"text.secondary",sx:{mb:2.5,display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical",overflow:"hidden"},children:t.description||"Single-elimination knockout. Winners advance, one player takes it all."}),(0,a.jsxs)(p.Z,{spacing:1,sx:{mb:2.5},children:[(0,a.jsxs)(p.Z,{direction:"row",spacing:1,sx:{alignItems:"center"},children:[a.jsx(Q.Z,{size:16,style:{color:r.palette.text.disabled}}),(0,a.jsxs)(d.Z,{variant:"body2",color:"text.secondary",children:["Starts ",function(e){let r=new Date(e);return Number.isNaN(r.getTime())?e:r.toLocaleString(void 0,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}(t.startsAt)]})]}),(0,a.jsxs)(p.Z,{direction:"row",spacing:1,sx:{alignItems:"center"},children:[a.jsx(Y.Z,{size:16,style:{color:r.palette.text.disabled}}),(0,a.jsxs)(d.Z,{variant:"body2",color:"text.secondary",children:[t.playersJoined,"/",t.maxPlayers," players"]})]}),t.prize&&(0,a.jsxs)(p.Z,{direction:"row",spacing:1,sx:{alignItems:"center"},children:[a.jsx(ee.Z,{size:16,style:{color:"#fbbf24"}}),a.jsx(d.Z,{variant:"body2",sx:{fontWeight:600,color:"#fcd34d"},children:t.prize})]})]}),a.jsx(n.Z,{sx:{mt:"auto",mb:3},children:a.jsx(U,{variant:"determinate",value:b,sx:{height:6,borderRadius:3,bgcolor:(0,u.Fq)(r.palette.text.primary,.1),"& .MuiLinearProgress-bar":{borderRadius:3,background:"#F5A306"}}})}),a.jsx(n.Z,{children:"registration"===t.status&&s?(0,a.jsxs)(n.Z,{sx:{p:1.25,textAlign:"center",borderRadius:3,border:"1px solid",borderColor:(0,u.Fq)(r.palette.success.main,.4),bgcolor:(0,u.Fq)(r.palette.success.main,.1),color:"success.light",fontWeight:700,fontSize:"0.875rem"},children:[(0,a.jsxs)(p.Z,{direction:"row",spacing:1,sx:{alignItems:"center",justifyContent:"center"},children:[a.jsx(er.Z,{size:16}),a.jsx("span",{children:"Joined"})]}),l?.message&&a.jsx(d.Z,{variant:"caption",sx:{display:"block",mt:.25,fontWeight:400,opacity:.8},children:l.message})]}):"registration"===t.status?e?a.jsx(c.Z,{fullWidth:!0,disabled:m||S===t.id,onClick:()=>void M(t),variant:"contained",sx:{py:1.25,fontWeight:800,background:"#F5A306",boxShadow:`0 4px 14px 0 ${(0,u.Fq)("#B25D16",.4)}`},children:S===t.id?a.jsx(et.Z,{size:18,className:"animate-spin"}):m?"Full":"Join"}):a.jsx(c.Z,{fullWidth:!0,component:o.default,href:"/login",variant:"contained",sx:{py:1.25,fontWeight:800,background:"#F5A306",boxShadow:`0 4px 14px 0 ${(0,u.Fq)("#B25D16",.4)}`},children:"Sign in to join"}):a.jsx(c.Z,{fullWidth:!0,component:o.default,href:`/tournaments/${t.id}`,variant:"outlined",sx:{py:1.25,fontWeight:800,borderColor:"divider",color:"text.secondary","&:hover":{borderColor:(0,u.Fq)(r.palette.primary.main,.5),color:"text.primary",bgcolor:(0,u.Fq)(r.palette.primary.main,.05)}},children:"in_progress"===t.status?"View Bracket":"View Results"})})]})},t.id)})})})]})})}},70662:(e,r,t)=>{"use strict";t.d(r,{Z:()=>P});var a=t(12131),i=t(40224),o=t(23677),n=t(91126),s=t(98964),l=t(97785),d=t(51732),c=t(25349),u=t(30096),p=t(82832),m=t(17409);function h(e){return(0,m.ZP)("MuiSkeleton",e)}(0,p.Z)("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);var b=t(73227);let x=["animation","className","component","height","style","variant","width"],g=e=>e,f,y,v,Z,j=e=>{let{classes:r,variant:t,animation:a,hasChildren:i,width:o,height:n}=e;return(0,l.Z)({root:["root",t,a,i&&"withChildren",i&&!o&&"fitContent",i&&!n&&"heightAuto"]},h,r)},k=(0,s.F4)(f||(f=g`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)),C=(0,s.F4)(y||(y=g`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)),w=(0,c.ZP)("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(e,r)=>{let{ownerState:t}=e;return[r.root,r[t.variant],!1!==t.animation&&r[t.animation],t.hasChildren&&r.withChildren,t.hasChildren&&!t.width&&r.fitContent,t.hasChildren&&!t.height&&r.heightAuto]}})(({theme:e,ownerState:r})=>{let t=String(e.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1]||"px",a=parseFloat(e.shape.borderRadius);return(0,i.Z)({display:"block",backgroundColor:e.vars?e.vars.palette.Skeleton.bg:(0,d.Fq)(e.palette.text.primary,"light"===e.palette.mode?.11:.13),height:"1.2em"},"text"===r.variant&&{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${a}${t}/${Math.round(a/.6*10)/10}${t}`,"&:empty:before":{content:'"\\00a0"'}},"circular"===r.variant&&{borderRadius:"50%"},"rounded"===r.variant&&{borderRadius:(e.vars||e).shape.borderRadius},r.hasChildren&&{"& > *":{visibility:"hidden"}},r.hasChildren&&!r.width&&{maxWidth:"fit-content"},r.hasChildren&&!r.height&&{height:"auto"})},({ownerState:e})=>"pulse"===e.animation&&(0,s.iv)(v||(v=g`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),k),({ownerState:e,theme:r})=>"wave"===e.animation&&(0,s.iv)(Z||(Z=g`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),C,(r.vars||r).palette.action.hover)),P=o.forwardRef(function(e,r){let t=(0,u.i)({props:e,name:"MuiSkeleton"}),{animation:o="pulse",className:s,component:l="span",height:d,style:c,variant:p="text",width:m}=t,h=(0,a.Z)(t,x),g=(0,i.Z)({},t,{animation:o,component:l,variant:p,hasChildren:!!h.children}),f=j(g);return(0,b.jsx)(w,(0,i.Z)({as:l,ref:r,className:(0,n.Z)(f.root,s),ownerState:g},h,{style:(0,i.Z)({width:m,height:d},c)}))})},7014:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>a});let a=(0,t(53189).createProxy)(String.raw`/Users/msl/Documents/GitHub/BaziGB-modular-architecture/apps/web/src/app/tournaments/page.tsx#default`)},40997:(e,r,t)=>{"use strict";t.d(r,{Z:()=>a});let a=(0,t(23147).Z)("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},15135:(e,r,t)=>{"use strict";t.d(r,{Z:()=>a});let a=(0,t(23147).Z)("refresh-cw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]])}};var r=require("../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[165,405,610,177,406,700],()=>t(40760));module.exports=a})();